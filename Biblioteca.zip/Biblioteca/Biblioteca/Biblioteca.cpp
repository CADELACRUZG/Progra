#include <iostream>
#include <string>
#include <cctype>
using namespace std;

class Libro {
private:
    string Titulo,Autor;
    string AnoDePublicacion, Paginas;
    bool Disponible;
public:
    Libro (string nombre, string autor, string ano, string pags, bool disp) {
        Titulo = nombre;
        Autor = autor;
        AnoDePublicacion = ano;
        Paginas = pags;
        Disponible = disp;
    }
    void MostrarValores() {
        cout << "Titulo: " + Titulo << endl;
        cout << "Autor: " + Autor << endl;
        cout << "Ano de publicacion: " + AnoDePublicacion << endl;
        cout << "Cantidad de paginas: " + Paginas << endl;
        cout << "Esta disponible: ";
        if (Disponible == true) {
            cout << " Disponible" << endl;
        }
        else {
            cout << " No disponible" << endl;
        }
    }
    string getTitulo() {
        return Titulo;
    }
    bool getDisponible() {
        return Disponible;
    }
    void setDisponible(bool disp) {
        Disponible = disp;
    }
};
class Biblioteca {
public:
    void BuscarLibro(string Titulo) {
        if (Titulo == "INSTITUCIONES DE DERECHO PROCESAL PENAL") {
            Libro libro1 ("INSTITUCIONES DE DERECHO PROCESAL PENAL", "Jacobo Lopez Barja De Quiroga", "1990", "600", true);
            libro1.MostrarValores();
        }
        else if (Titulo == "APRECIACION JUDICIAL DE LAS PRUEBAS") {
            Libro libro2 ("APRECIACION JUDICIAL DE LAS PRUEBAS", "Francois Gorphe", "1996", "411", false);
            libro2.MostrarValores();
        }
        else if (Titulo == "LOS ORIGENES DEL DERECHO AL TRABAJO EN FRANCIA") {
            Libro libro3 ("LOS ORIGENES DEL DERECHO AL TRABAJO EN FRANCIA", "Pablo Scotto", "1848", "486", true);
            libro3.MostrarValores();
        }
        else {
            cout << "Libro no disponible en esta biblioteca" << endl;
        }
    }
};
class Menu {
public:
    Biblioteca biblio;
    string eleccion;
    void menuPrincipal() {
        cout << "BIENVENIDO!" << endl;
        do {
            cout << "Que deseas realizar?" << endl;
            cout << "1) Prestar un libro \n2) Devolver un libro \n3) Consultar datos de un libro \n4) Consultar disponibilidad \n5) Salir" << endl;
            cin >> eleccion;
            if (eleccion == "1") {
                opcion1();
            }
            else if (eleccion == "2") {
                opcion2();
            }
            else if (eleccion == "3") {
                opcion3();
            }
            else if (eleccion == "4"){
                opcion4();
            }
            else if (eleccion == "5") {
                exit(0);
            }
            else {
                cout << "Eleccion no valida, vuelve a intenar" << endl;
            }
        } while (true);
    }
    void opcion1() {
        int opcion;
        cout << "Selecciona el libro que desees prestar: " << endl;
        cout << "\n1)" << endl;
        Libro libro1("INSTITUCIONES DE DERECHO PROCESAL PENAL", "Jacobo Lopez Barja De Quiroga", "1990", "600", true);
        libro1.MostrarValores();
        cout << "\n2)" << endl;
        Libro libro2("APRECIACION JUDICIAL DE LAS PRUEBAS", "Francois Gorphe", "1996", "411", false);
        libro2.MostrarValores();
        cout << "\n3)" << endl;
        Libro libro3("LOS ORIGENES DEL DERECHO AL TRABAJO EN FRANCIA", "Pablo Scotto", "1848", "486", true);
        libro3.MostrarValores();
        cin >> opcion;
        switch (opcion) {
        case 1:
            if (libro1.getDisponible() == false) {
                cout << "Lo sentimos, en estos instantes este libro no se encuentra disponible" << endl;
            }
            else {
                cout << "Enhora buena! que no se te olvide regresar el libro luego..." << endl;
                libro1.setDisponible(false);
            }
            break;
        case 2:
            if (libro2.getDisponible() == false) {
                cout << "Lo sentimos, en estos instantes este libro no se encuentra disponible" << endl;
            }
            else {
                cout << "Enhora buena! que no se te olvide regresar el libro luego..." << endl;
                libro2.setDisponible(false);
            }
            break;
        case 3:
            if (libro3.getDisponible() == false) {
                cout << "Lo sentimos, en estos instantes este libro no se encuentra disponible" << endl;
            }
            else {
                cout << "Enhora buena! que no se te olvide regresar el libro luego..." << endl;
                libro3.setDisponible(false);
            }
            break;
        defaul:
            cout << "Lo sentimos, ese libro parece no existir..." << endl;
        }
    }
    void opcion2() {
        string nombreLibro;
        cout << "Ingrese el nombre del libro que va a regresar: ";
        cin >> nombreLibro;
        Libro libro4(nombreLibro, "", "", "", true);
        cout << "Te esperamos de regreso, recuerda que la literatura nutre la mente!!" << endl;
    }
    void opcion3() {
        string titulo;
        cout << "Ingresa el nombre del libro que estas buscando" << endl;
        cin.ignore();
        getline(cin, titulo); //se utiliza para leer todo el título porque cin solo lee hasta el primer espacio
        for (char& c : titulo) { //se recorre cada caracter del texto ingresado
            c = toupper(c);//convierto el texto ingresado en mayúsculas
        }
        biblio.BuscarLibro(titulo);
    }
    void opcion4() {
        
        Libro libro1("INSTITUCIONES DE DERECHO PROCESAL PENAL", "Jacobo Lopez Barja De Quiroga", "1990", "600", true);
        Libro libro2("APRECIACION JUDICIAL DE LAS PRUEBAS", "Francois Gorphe", "1996", "411", false);
        Libro libro3("LOS ORIGENES DEL DERECHO AL TRABAJO EN FRANCIA", "Pablo Scotto", "1848", "486", true);
        cout << libro1.getTitulo() << endl;
        if (libro1.getDisponible() == true) {
            cout << "Disponible" << endl;
        }
        else {
            cout << "No disponible" << endl;
        }
        cout << libro2.getTitulo() << endl;
        if (libro2.getDisponible() == true) {
            cout << "Disponible" << endl;
        }
        else {
            cout << "No disponible" << endl;
        }
        cout << libro3.getTitulo() << endl;
        if (libro3.getDisponible() == true) {
            cout << "Disponible" << endl;
        }
        else {
            cout << "No disponible" << endl;
        }
    }
};
int main() {
    Menu men;
    men.menuPrincipal();
}

